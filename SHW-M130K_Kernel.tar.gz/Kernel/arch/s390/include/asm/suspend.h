#ifndef __ASM_S390_SUSPEND_H
#define __ASM_S390_SUSPEND_H

static inline int arch_prepare_suspend(void)
{
	return 0;
}

#endif

